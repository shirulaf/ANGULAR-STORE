
angular.module("myApp")
    .controller('retriveController', ['$location', '$http','$scope', function ($location, $http, $scope) {


        $scope.restore = function()
        {
            $http.post('http://localhost:8000/Users/PasswordRestoreAnswer', {

                userName: $scope.UserName,
                Ans1:$scope.first ,
                Ans2: $scope.second

            })
                .then(function(result)
                {
                    if( result.data.length == 1){

                        window.alert( "YOUR PASSWORD IS:  " + result.data["0"].password)
                        $location.path('/')
                        $route.reload()
                    }
                    else{
                        window.alert("No match")
                    }

                })
        }


    }]);
