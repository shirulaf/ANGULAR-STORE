
let app = angular.module('myApp', ['ngRoute', 'LocalStorageModule','ngDialog']);
//-------------------------------------------------------------------------------------------------------------------
app.config(function (localStorageServiceProvider) {
    localStorageServiceProvider.setPrefix('node_angular_App');
});
//-------------------------------------------------------------------------------------------------------------------

//-------------------------------------------------------------------------------------------------------------------
app.controller('loginController', ['UserService', 'localStorageModel', 'HomeModel', '$location', '$window', '$scope', '$rootScope', '$route',
    function(UserService,localStorageModel, HomeModel, $location, $window, $scope, $rootScope, $route) {
        let self = this;




        self.login = function(valid) {
            let name=$scope.user.UserName

            if (valid) {


                UserService.login( $scope.user)
                    .then(function (success) {

                        $window.alert('You Successfully logged in!');

                        HomeModel.setVal("true")
                        $rootScope.login="true"

                        $location.path('/')

                        $route.reload()

                    }). catch (function  (error) {
                    console.log(error)
                    $window.alert('log-in has failed');
                });
            }
        };
    }]);
//-------------------------------------------------------------------------------------------------------------------

//-------------------------------------------------------------------------------------------------------------------
app.factory('UserService', ['$rootScope','$http', '$window','localStorageModel' ,  function($rootScope,$http, $window, localStorageModel) {
    let service = {};
    service.isLoggedIn = false;




    service.login = function(user) {

        params = { UserName : user.UserName , password : user.password }


        return $http.post("http://localhost:8000/Users/Login", params)
            .then(function(response) {

                let token = response.data.cookieID;
                console.log(token)



                    var today = new Date();
                    var dd = today.getDate();
                    var mm = today.getMonth()+1; //January is 0!
                    var yyyy = today.getFullYear();

                    if(dd<10) {
                        dd = '0'+dd
                    }

                    if(mm<10) {
                        mm = '0'+mm
                    }

                   var today = mm + '/' + dd + '/' + yyyy;



                $rootScope.userName=user.UserName
                $rootScope.login="true"
                $rootScope.LoginDate=today
                localStorageModel.addLocalStorage('userName', user.UserName)
                localStorageModel.addLocalCookie('cookieID', token)
                localStorageModel.addLocalStorage('LoginDate', today)

                $http.defaults.headers.common = {
                    'CookieID': token,
                    'user' : user.UserName
                };
                service.isLoggedIn = true;
                console.log("return promise")
                return Promise.resolve(response);
            })
            .catch(function (e) {
                return Promise.reject(e);
            });
    };



    return service;
}]);
//-------------------------------------------------------------------------------------------------------------------
app.config(['$locationProvider', function($locationProvider) {
    $locationProvider.hashPrefix('');
}]);
//----------------------------------------------------------------
app.config( ['$routeProvider', function($routeProvider) {
    $routeProvider
        .when("/", {
            templateUrl : "./components/Home/home.html",
            controller : "HomeController as homCtrl"
        })
        .when("/login", {
            templateUrl : "./components/Home/Login.html",
            controller: "loginController as logCtrl"
        })
        .when("/register", {
            templateUrl : "./components/Register/register.html",
            controller: "RegisterController as RegCtrl"
        })
        .when("/products", {
            templateUrl : "./components/Products/products.html",
            controller : "ProductsController as prodCtrl"
        })

        .when("/StorageExample", {
            templateUrl : "views/StorageExample.html",
            controller: 'StorageExampleController'
        })
        .when("/about", {
            templateUrl : "./components/about.html",
            // controller: 'StorageExampleController'
        })
        .when("/cart", {
            templateUrl:"./components/Cart/cart.html",
            controller: "CartController"
        })
        .when("/retrivePass",
            {
                templateUrl: "./components/Home/Password/retrievePass.html",
                controller:"retriveController as rtvCtrl"
            })

        .otherwise({redirect: '/',
        });
}]);
//-------------------------------------------------------------------------------------------------------------------



