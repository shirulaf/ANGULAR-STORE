/**
 * Created by user on 04/08/2017.
 */
angular.module("myApp")
    .controller('SignOutController' , ['localStorageModel','$location', '$scope', 'LoginModel', '$route', function(localStorageModel, $location , $scope, LoginModel, $route)
    {

        $scope.signOut= function ()
         {


            localStorageModel.removeLocalStorage('userName')
            localStorageModel.removeLocalStorage('LoginTime')
            localStorageModel.removeCookie('cookieID')

             LoginModel.checkLogin()
            $location.path('/')
            $route.reload()


        }


    }])
