
angular.module("myApp")
    .service('LoginModel' ,['$http', 'localStorageModel', 'HomeModel', '$rootScope', function ($http, localStorageModel, HomeModel, $rootScope) {

        let self=this;



        //checks if coolie exists in local storage - if so teh user is logged in
        self.checkLogin = function () {
            console.log("check Login")

            if (localStorageModel.getCookie("cookieID") != null) {
                console.log("cookie=true")
                HomeModel.setVal(true)//this model allows accsses from differnet controllers to see if teh user is connectes
                $rootScope.userName = localStorageModel.getLocalStorage("userName")
                $rootScope.LoginDate = localStorageModel.getLocalStorage("LoginDate")
                $rootScope.login = true// change the bar display for login users - for the $rootScope binding

                $http.defaults.headers.common = {
                    'CookieID': localStorageModel.getCookie("cookieID"),
                    'user': $rootScope.userName,

                };


            }
            else
            {
                $rootScope.login = false // change the bar display for login users - for the $rootScope binding
                $rootScope.LoginDate = ""

                HomeModel.setVal(false)
                $rootScope.userName="Guest"
            }
        }
    }])



